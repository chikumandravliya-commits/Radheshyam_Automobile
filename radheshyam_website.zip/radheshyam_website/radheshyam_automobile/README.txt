RADHESHYAM AUTOMOBILE - RESPONSIVE WEBSITE

Files:
- index.html: website structure and content
- style.css: responsive layout and visual design
- script.js: year and WhatsApp enquiry form
- assets/: original poster, promotional image and workshop photo supplied by the owner

HOW TO RUN:
1. Extract the ZIP file.
2. Keep the assets folder beside index.html.
3. Double-click index.html to preview in a browser.
4. Internet is needed for Bootstrap CDN and Google Fonts.

CUSTOMIZE:
- Contact / WhatsApp number is set in script.js (918502007794).
- Phone numbers and workshop address are in index.html.
- Replace or update the images inside assets if needed.

Note: Website enquiry form opens WhatsApp; it does not store bookings in a database.
